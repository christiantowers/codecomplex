<div id="services" style="height: 320px; background-color:white;" >
		<div style="width: 332px; height: 160px;float:left; border-bottom:thin solid #cccccc; border-right:thin solid #cccccc; ">
			<table>
				<tr>
					<td width="60px">
						<img style="margin: 25px 25px 25px 25px;  " src="<?php echo URL_IMG_WEBSITE ?>/service-1.png">
					</td>
					<td width="170px">
						<div style="padding-left:25px;">
							<h5 style="margin-top:15px" >Desenvolvimento</h5>
							<p class="font_13" style="color:#888888;  line-height:125%;" >Desenvolvemos produtos conforme sua necessidade com agilidade e flexibilidade.</p>
						</div>
					</td>
				</tr>
			</table>				
		</div>
		<div style="width: 332px; height: 160px;float:left; border-bottom:thin solid #cccccc; border-right:thin solid #cccccc; ">
			<table>
				<tr height="130px" >
					<td width="60px">
						<img style="margin: 25px 25px 25px 25px;  " src="<?php echo URL_IMG_WEBSITE ?>/service-2.png">
					</td>
					<td width="170px">
						<div style="padding-left:25px;">
							<h5 style="margin-top:15px" >Segurança Web</h5>
							<p class="font_13" style="color:#888888; line-height:125%;" >Conhecemos os problemas relacionados a segurança, mas também como resolve-los.</p>
						</div>
					</td>
				</tr>
			</table>				
		</div>
		<div style="width: 332px; height: 160px;float:left;  border-bottom:thin solid #cccccc; ">
			<table>
				<tr height="130px" >
					<td width="60px">
						<img style="margin: 25px 25px 25px 25px; " src="<?php echo URL_IMG_WEBSITE ?>/service-3.png">
					</td>
					<td width="170px">
						<div style="padding-left:25px;">
							<h5 style="margin-top:15px" >Arquitetura</h5>
							<p class="font_13" style="color:#888888; line-height:125%;" >Projetamos o seu sistema com a arquitetura que você precisa.</p>
						</div>
					</td>
				</tr>
			</table>				
		</div>
		<div style="width: 332px; height: 175px;float:left;  border-right:thin solid #cccccc; ">
			<table>
				<tr height="130px" >
					<td width="60px">
						<img style="margin: 25px 25px 25px 25px;  " src="<?php echo URL_IMG_WEBSITE ?>/service-4.png">
					</td>
					<td width="170px">
						<div style="padding-left:25px;">
							<h5 style="margin-top:15px" >Middleware</h5>
							<p class="font_13" style="color:#888888; line-height:125%;" >Se você precisa integrar seu sistema, também temos a solução.</p>
						</div>
					</td>
				</tr>
			</table>				
		</div>
		<div style="width: 332px; height: 175px;float:left;  border-right:thin solid #cccccc;">
			<table>
				<tr height="130px" >
					<td width="60px">
						<img style="margin: 25px 25px 25px 25px;  " src="<?php echo URL_IMG_WEBSITE ?>/service-5.png">
					</td>
					<td width="170px">
						<div style="padding-left:25px;">
							<h5 style="margin-top:15px" >Documentação</h5>
							<p class="font_13" style="color:#888888; line-height:125%;" >Oferemos serviços de consultoria em testes e construção de software.</p>
						</div>
					</td>
				</tr>
			</table>				
		</div>
		<div style="width: 332px; height: 175px;float:left; ">
			<table>
				<tr height="130px" >
					<td width="60px">
						<img style="margin: 25px 25px 25px 25px;  " src="<?php echo URL_IMG_WEBSITE ?>/service-6.png">
					</td>
					<td width="170px">
						<div style="padding-left:25px;">
							<h5 style="margin-top:15px" >Software e Infra</h5>
							<p class="font_13" style="color:#888888; line-height:125%;" >Se você não quer se preocupar com nada. Oferecemos o serviço completo construção do seu software, hospedagem, etc.</p>
						</div>
					</td>
				</tr>
			</table>				
		</div>
	</div>
	
	<br />