<?php echo start_box('Mais Downloads', URL_IMG_WEBSITE . '/icon_info.png', 'float:right;width:200px;margin-top:30px;'); ?><?php echo 'Content goes here'; ?><?php echo end_box(); ?>
<h2>Downloads</h2>
<hr />
<p><br />Fa&ccedil;a download da &uacute;ltima vers&atilde;o do ACME Engine.<br /><br /></p>
<?php echo 'example';<br />echo start_box(); ?>