<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Acme_User
* 
* Classe abstra��o de m�dulo base da aplica��o.
*
* @since		13/08/2012
* @package		controllers.acme_module_base
*/
$lang['login'] = 'login';
