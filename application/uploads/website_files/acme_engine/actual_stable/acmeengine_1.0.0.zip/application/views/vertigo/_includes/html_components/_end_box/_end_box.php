<?php
/**
* _end_box()
* Finaliza o html de uma caixa genérica.
* @return string end_box
*/
function _end_box()
{
	$html  = '</div></div>';
	return $html;
}